-- AlterTable
ALTER TABLE "Flashcard" ADD COLUMN     "isDifficult" BOOLEAN NOT NULL DEFAULT false;
